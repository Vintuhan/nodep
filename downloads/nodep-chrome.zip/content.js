// nodep project — проверка открытой страницы.
// Порядок: белый список -> адрес + заголовки -> (если есть подозрение) текст, кнопки, формы.
// Оптимизация: на «чистых» сайтах почти ничего не делаем (нет innerText, нет повторных проходов).
(function () {
  if (!/^https?:$/.test(location.protocol)) return;

  const host = location.hostname.toLowerCase().replace(/^www\./, "");

  // Быстрый выход до любых DOM-запросов и storage, если домен точно «свой»
  // (белый список вшит в data/whitelist.js и уже загружен вместе со скриптом).
  if (self.nodepIsWhitelisted && self.nodepIsWhitelisted(host)) return;

  const S = self.NodepScoring;
  if (!S) return;

  let blocked = false;
  let asked = false;
  let cardRoot = null;
  let maxScoreSeen = 0; // чтобы не гонять тяжёлые проходы зря

  // ---------- лёгкий сбор текста ----------

  function headingTexts() {
    const out = [document.title || ""];
    try {
      const og = document.querySelector('meta[property="og:site_name"]');
      if (og && og.content) out.push(og.content);
    } catch (e) {}
    try {
      const hs = document.querySelectorAll("h1,h2");
      for (let i = 0; i < hs.length && i < 20; i++) {
        const t = (hs[i].textContent || "").trim();
        if (t) out.push(t.slice(0, 160));
      }
    } catch (e) {}
    return out;
  }

  // innerText дорогой (layout). Берём урезанный textContent и режем рано.
  function bodyTextLight() {
    try {
      if (!document.body) return "";
      // textContent не форсирует layout так агрессивно, как innerText
      return (document.body.textContent || "").replace(/\s+/g, " ").trim().slice(0, 3500);
    } catch (e) {
      return "";
    }
  }

  function looksLikeArticle() {
    try {
      const og = document.querySelector('meta[property="og:type"]');
      if (og && /article/i.test(og.content || "")) return true;
      if (document.querySelector('meta[property="article:published_time"]')) return true;
      const ld = document.querySelectorAll('script[type="application/ld+json"]');
      for (let i = 0; i < ld.length && i < 3; i++) {
        if (/"@type"\s*:\s*"(News|Blog)?(Posting|Article)"/i.test(ld[i].textContent || "")) return true;
      }
      const art = document.querySelector("article");
      return !!(art && art.querySelectorAll("p").length >= 5);
    } catch (e) {
      return false;
    }
  }

  function structureTexts() {
    const out = [];
    try {
      const els = document.querySelectorAll("a,button,[role=\"button\"]");
      for (let i = 0; i < els.length && i < 200; i++) {
        const t = (els[i].textContent || "").trim();
        if (t && t.length <= 40) out.push(t);
      }
      const inputs = document.querySelectorAll("input[placeholder]");
      for (let i = 0; i < inputs.length && i < 30; i++) {
        const p = inputs[i].placeholder;
        if (p) out.push(p);
      }
    } catch (e) {}
    return out;
  }

  // ---------- действия ----------

  function doBlock(why, score) {
    if (blocked) return;
    blocked = true;
    if (cardRoot) {
      try { cardRoot.remove(); } catch (e) {}
    }
    try { chrome.runtime.sendMessage({ type: "auto-block", why, score }); } catch (e) {}
  }

  function isTrusted(cb) {
    try {
      chrome.storage.local.get("trustedUntil", ({ trustedUntil = {} }) => {
        cb((trustedUntil[host] || 0) > Date.now());
      });
    } catch (e) {
      cb(false);
    }
  }

  function trustForADay() {
    try {
      chrome.storage.local.get("trustedUntil", ({ trustedUntil = {} }) => {
        trustedUntil[host] = Date.now() + 24 * 60 * 60 * 1000;
        chrome.storage.local.set({ trustedUntil });
      });
    } catch (e) {}
  }

  // ---------- решение ----------

  // pass: 0 = только домен+заголовки (дёшево), 1+ = полный скан
  function evaluate(pass) {
    if (blocked) return false;

    const domainS = Math.max(
      S.scoreDomain(host),
      S.scoreUrl ? S.scoreUrl(location.href) : 0
    );
    if (domainS >= S.CERTAIN) {
      doBlock("brand", domainS);
      return true;
    }

    const textS = S.scoreTitleAndHeadings(headingTexts());
    const cheap = domainS + textS;
    maxScoreSeen = Math.max(maxScoreSeen, cheap);

    // Ноль подозрений — дальше ничего не трогаем (самый частый случай на обычных сайтах)
    if (cheap <= 0 && pass === 0) return false;
    if (cheap <= 0 && pass > 0 && maxScoreSeen <= 0) return false;

    // Полный скан только если уже есть намёк
    let bodyS = 0;
    let structS = 0;
    if (cheap > 0 || pass > 0) {
      bodyS = S.scoreBody(bodyTextLight());
      structS = S.scoreStructure(structureTexts());
      maxScoreSeen = Math.max(maxScoreSeen, domainS + textS + bodyS + structS);
    }

    const verdict = S.decide(domainS, textS, bodyS, structS, looksLikeArticle());
    if (verdict === "block") {
      doBlock("score", domainS + textS + bodyS + structS);
      return true;
    }
    if (verdict === "ask" && !asked) {
      asked = true;
      isTrusted((trusted) => {
        if (!trusted && !blocked) showCard();
      });
    }
    return maxScoreSeen > 0;
  }

  // ---------- плашка ----------

  function showCard() {
    if (blocked || document.getElementById("nodep-root")) return;

    // Шрифт подгружаем только когда реально показываем карточку
    const fontSrc = ["woff2:woff2", "woff:woff", "ttf:truetype", "otf:opentype"]
      .map((p) => {
        const [ext, fmt] = p.split(":");
        return 'url("' + chrome.runtime.getURL("fonts/Tovar." + ext) + '") format("' + fmt + '")';
      })
      .join(",");
    const fontStyle = document.createElement("style");
    fontStyle.textContent = '@font-face{font-family:"NodepTovar";src:' + fontSrc + ";font-display:swap}";
    (document.head || document.documentElement).appendChild(fontStyle);

    const root = document.createElement("div");
    root.id = "nodep-root";
    cardRoot = root;
    const shadow = root.attachShadow({ mode: "closed" });
    shadow.innerHTML = `
      <style>
        :host { all: initial; }
        .card {
          position: fixed; top: 18px; right: 18px; z-index: 2147483647;
          width: 320px; max-width: calc(100vw - 36px); box-sizing: border-box;
          padding: 24px 22px 20px; background: #000; color: #fff; text-align: center;
          border: 1px solid rgba(255,255,255,.85);
          box-shadow: 0 10px 40px rgba(0,0,0,.45);
          font-family: "NodepTovar","Arial Narrow","Helvetica Neue",Arial,sans-serif;
          opacity: 0; transform: translateY(-8px); transition: opacity .25s, transform .25s;
        }
        .card.show { opacity: 1; transform: none; }
        .brand { font-size: 26px; line-height: 1; margin-bottom: 14px; font-weight: 400; }
        .q { font-size: 14px; line-height: 1.45; margin: 0 0 18px; color: #fff; }
        button {
          display: block; width: 100%; box-sizing: border-box; margin-top: 8px; padding: 12px 14px;
          font: inherit; font-size: 14px; cursor: pointer;
          color: #fff; background: transparent; border: 1px solid rgba(255,255,255,.7);
          transition: background .15s, color .15s;
        }
        button:hover:not(:disabled) { background: #fff; color: #000; }
        button.solid { background: #fff; color: #000; border-color: #fff; }
        button.solid:hover:not(:disabled) { background: #000; color: #fff; }
        button:disabled { opacity: .4; cursor: default; }
        button:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }
        @media (prefers-reduced-motion: reduce) { .card { transition: none; } }
      </style>
      <div class="card" role="dialog" aria-label="nodep project">
        <div class="brand">nodep project</div>
        <p class="q">возможно, сайт как-то связан с азартными играми?</p>
        <button class="solid" id="yes" type="button">да, блокировать сайт</button>
        <button id="no" type="button" disabled>нет, всё ок (5)</button>
      </div>`;
    document.documentElement.appendChild(root);
    requestAnimationFrame(() => {
      const c = shadow.querySelector(".card");
      if (c) c.classList.add("show");
    });

    const no = shadow.getElementById("no");
    let left = 5;
    const timer = setInterval(() => {
      left--;
      if (left > 0) {
        no.textContent = "нет, всё ок (" + left + ")";
        return;
      }
      clearInterval(timer);
      no.textContent = "нет, всё ок";
      no.disabled = false;
    }, 1000);

    shadow.getElementById("yes").addEventListener("click", () => {
      clearInterval(timer);
      try { chrome.runtime.sendMessage({ type: "block-site" }); } catch (e) {}
      root.remove();
    });
    no.addEventListener("click", () => {
      clearInterval(timer);
      trustForADay();
      root.remove();
    });
  }

  // Ступенчато: 0 — домен+заголовки (дёшево);
  // при подозрении — быстрый полный скан (0.8 с), потом SPA (2.5 с / 5 с).
  try {
    (async () => {
      try {
        await self.nodepLoadExtra();
      } catch (e) {}
      if (self.nodepIsWhitelisted(host)) return;

      // мгновенно: домен + путь URL (case-battle в path тоже)
      const domainOnly = S.scoreDomain(host);
      const urlOnly = S.scoreUrl ? S.scoreUrl(location.href) : 0;
      if (Math.max(domainOnly, urlOnly) >= S.CERTAIN) {
        doBlock("brand", Math.max(domainOnly, urlOnly));
        return;
      }

      const needMore = evaluate(0);
      if (!needMore) return;

      // есть баллы → углубляемся быстрее, чем раньше
      setTimeout(() => { if (!blocked) evaluate(1); }, 800);
      setTimeout(() => { if (!blocked) evaluate(2); }, 2500);
      setTimeout(() => { if (!blocked) evaluate(3); }, 5000);
    })();
  } catch (e) {}
})();
