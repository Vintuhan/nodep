// nodep project — фоновый скрипт (v0.7)
// 1) Базы gambling-доменов → declarativeNetRequest (блок до загрузки страницы)
// 2) Fallback webNavigation (бренд в URL, то что не влезло в DNR)
// 3) Списки + approved с сервера
// 4) Сообщения от content / popup

importScripts("data/whitelist.js", "data/keywords.js", "scoring.js", "config.js");

const LIST_URLS = [
  "https://raw.githubusercontent.com/blocklistproject/Lists/master/gambling.txt",
  "https://blocklistproject.github.io/Lists/gambling.txt",
  "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/gambling-only/hosts",
  "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/domains/gambling.mini.txt"
];
const MAX_REMOTE_DOMAINS = 50000;
const DNR_MAX_RULES = 4500; // запас до лимита Chrome на dynamic rules
const DNR_ID_START = 1000;
const UPDATE_EVERY_MINUTES = 12 * 60;

let cache = null;
let cachePromise = null;
let extraReady = false;

// ---------- кэш доменов ----------

async function loadCache() {
  const seed = await (await fetch(chrome.runtime.getURL("data/seed.json"))).json();
  const { remote = [], custom = [] } = await chrome.storage.local.get(["remote", "custom"]);
  cache = new Set([...seed, ...remote, ...custom]);
  return cache;
}

async function getCache() {
  if (cache) return cache;
  if (!cachePromise) cachePromise = loadCache().finally(() => { cachePromise = null; });
  return cachePromise;
}

getCache().catch(() => {});
if (typeof self.nodepLoadExtra === "function") {
  self.nodepLoadExtra().then(() => { extraReady = true; }).catch(() => {});
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.remote || changes.custom) {
    cache = null;
    cachePromise = null;
    syncDnrRules().catch(() => {});
  }
  if (changes.remoteWhitelist) {
    extraReady = false;
    syncDnrRules().catch(() => {});
  }
});

// ---------- парсинг списков ----------

const DOMAIN_RE = /^(?=.{4,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/;

function parseList(text) {
  const result = [];
  for (const rawLine of text.split(/\r?\n/)) {
    let line = rawLine.split("#")[0].trim().toLowerCase();
    if (!line) continue;
    line = line.replace(/^local=\/?/, "").replace(/\/$/, "");
    const parts = line.split(/\s+/);
    let domain = parts[parts.length - 1];
    domain = domain.replace(/^\|\|/, "").replace(/\^$/, "").replace(/^\*\./, "");
    if (domain === "localhost" || domain.endsWith(".localhost")) continue;
    if (DOMAIN_RE.test(domain)) result.push(domain);
  }
  return result;
}

async function updateLists() {
  const all = new Set();
  let okLists = 0;
  for (const url of LIST_URLS) {
    try {
      const response = await fetch(url, { cache: "no-store" });
      if (!response.ok) continue;
      parseList(await response.text()).forEach((d) => all.add(d));
      okLists++;
    } catch (e) {}
  }
  if (okLists > 0 && all.size > 0 && all.size <= MAX_REMOTE_DOMAINS) {
    await chrome.storage.local.set({ remote: [...all], updatedAt: Date.now() });
    cache = null;
    await syncDnrRules();
  }
}

async function updateApproved() {
  const api = self.NODEP_REPORT_API;
  if (!api) return;
  try {
    const response = await fetch(api + (api.includes("?") ? "&" : "?") + "action=approved", { cache: "no-store" });
    if (!response.ok) return;
    const data = await response.json();
    if (data && data.ok && Array.isArray(data.approved)) {
      await chrome.storage.local.set({
        remoteWhitelist: data.approved.filter((d) => typeof d === "string").slice(0, 20000)
      });
      extraReady = false;
      await syncDnrRules();
    }
  } catch (e) {}
}

// ---------- declarativeNetRequest ----------

function blockedPageUrl(host, why) {
  const q = new URLSearchParams({ host: host || "", why: why || "list", score: "0", u: "" });
  return chrome.runtime.getURL("blocked.html") + "?" + q.toString();
}

async function getExcludeSet() {
  const set = new Set();
  try {
    if (typeof self.nodepLoadExtra === "function") await self.nodepLoadExtra();
  } catch (e) {}
  try {
    const { remoteWhitelist = [] } = await chrome.storage.local.get("remoteWhitelist");
    remoteWhitelist.forEach((h) => set.add(String(h).toLowerCase()));
  } catch (e) {}
  // встроенный whitelist — не кладём в DNR (проверка через nodepIsWhitelisted при навигации)
  return set;
}

function isWhitelistedHost(hostname) {
  try {
    if (typeof self.nodepIsWhitelisted === "function" && self.nodepIsWhitelisted(hostname)) return true;
  } catch (e) {}
  return false;
}

async function syncDnrRules() {
  if (!chrome.declarativeNetRequest) return;

  const set = await getCache();
  const exclude = await getExcludeSet();

  // Приоритет: custom → seed/remote. Обрезаем до DNR_MAX_RULES.
  const { custom = [] } = await chrome.storage.local.get("custom");
  const ordered = [];
  const seen = new Set();
  for (const d of custom) {
    const h = String(d).toLowerCase();
    if (!h || seen.has(h) || exclude.has(h) || isWhitelistedHost(h)) continue;
    seen.add(h);
    ordered.push(h);
  }
  for (const d of set) {
    const h = String(d).toLowerCase();
    if (!h || seen.has(h) || exclude.has(h) || isWhitelistedHost(h)) continue;
    seen.add(h);
    ordered.push(h);
    if (ordered.length >= DNR_MAX_RULES) break;
  }

  const rules = ordered.map((domain, i) => ({
    id: DNR_ID_START + i,
    priority: 1,
    action: {
      type: "redirect",
      redirect: { url: blockedPageUrl(domain, "list") }
    },
    condition: {
      requestDomains: [domain],
      resourceTypes: ["main_frame"]
    }
  }));

  // Снять старые dynamic-правила в нашем диапазоне
  try {
    const existing = await chrome.declarativeNetRequest.getDynamicRules();
    const removeIds = existing
      .map((r) => r.id)
      .filter((id) => id >= DNR_ID_START && id < DNR_ID_START + DNR_MAX_RULES + 500);
    // Chrome: update max ~5000 за раз; режем пачками
    for (let i = 0; i < removeIds.length; i += 1000) {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: removeIds.slice(i, i + 1000)
      });
    }
  } catch (e) {}

  for (let i = 0; i < rules.length; i += 500) {
    try {
      await chrome.declarativeNetRequest.updateDynamicRules({
        addRules: rules.slice(i, i + 500)
      });
    } catch (e) {
      // лимит / квота — остальное останется на webNavigation
      break;
    }
  }

  await chrome.storage.local.set({ dnrCount: rules.length, dnrAt: Date.now() });
}

// ---------- старт / таймеры ----------

async function boot() {
  try {
    const { remote = [] } = await chrome.storage.local.get("remote");
    if (remote.length > MAX_REMOTE_DOMAINS) await chrome.storage.local.remove("remote");
  } catch (e) {}
  chrome.alarms.create("update-lists", { delayInMinutes: 0.1, periodInMinutes: UPDATE_EVERY_MINUTES });
  chrome.alarms.create("update-approved", { delayInMinutes: 1, periodInMinutes: 60 });
  await getCache().catch(() => {});
  await syncDnrRules().catch(() => {});
}

chrome.runtime.onInstalled.addListener(() => { boot(); });
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("update-lists", { delayInMinutes: 0.5, periodInMinutes: UPDATE_EVERY_MINUTES });
  chrome.alarms.create("update-approved", { delayInMinutes: 1, periodInMinutes: 60 });
  getCache().catch(() => {});
  syncDnrRules().catch(() => {});
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "update-lists") {
    updateLists();
    updateApproved();
  } else if (alarm.name === "update-approved") {
    updateApproved();
  }
});

// ---------- fallback: webNavigation (бренд / то, что не в DNR) ----------

function isBlocked(hostname, set) {
  const labels = hostname.toLowerCase().replace(/\.$/, "").split(".");
  for (let i = 0; i < labels.length - 1; i++) {
    if (set.has(labels.slice(i).join("."))) return true;
  }
  return false;
}

function openBlockedPage(tabId, hostname, why, score, fullUrl) {
  const q = new URLSearchParams({
    host: hostname,
    why: why || "list",
    score: String(score || 0),
    u: fullUrl || ""
  });
  chrome.tabs.update(tabId, { url: chrome.runtime.getURL("blocked.html") + "?" + q.toString() });
}

chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0) return;
  let url;
  try { url = new URL(details.url); } catch (e) { return; }
  if (url.protocol !== "http:" && url.protocol !== "https:") return;
  // страница расширения — не трогаем
  if (url.href.startsWith(chrome.runtime.getURL(""))) return;

  if (!extraReady && typeof self.nodepLoadExtra === "function") {
    try {
      await self.nodepLoadExtra();
      extraReady = true;
    } catch (e) {}
  }
  if (isWhitelistedHost(url.hostname)) return;

  const set = await getCache();
  const domainS = self.NodepScoring.scoreDomain(url.hostname);
  const urlS = self.NodepScoring.scoreUrl
    ? self.NodepScoring.scoreUrl(url.href)
    : 0;
  const brandHit = Math.max(domainS, urlS) >= self.NodepScoring.CERTAIN;
  if (isBlocked(url.hostname, set)) {
    openBlockedPage(details.tabId, url.hostname, "list", 0, details.url);
  } else if (brandHit) {
    openBlockedPage(details.tabId, url.hostname, "brand", Math.max(domainS, urlS), details.url);
  }
});

// ---------- сообщения ----------

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "force-update") {
    Promise.all([updateLists(), updateApproved(), syncDnrRules()])
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg && msg.type === "get-status") {
    chrome.storage.local.get(["remote", "custom", "updatedAt", "dnrCount", "strictMode"]).then((s) => {
      sendResponse({
        ok: true,
        remote: (s.remote || []).length,
        custom: (s.custom || []).length,
        dnr: s.dnrCount || 0,
        updatedAt: s.updatedAt || 0,
        strictMode: !!s.strictMode
      });
    });
    return true;
  }

  if (!sender.tab || !sender.tab.url) return;
  let hostname;
  try { hostname = new URL(sender.tab.url).hostname; } catch (e) { return; }
  const run = () => handleMessage(msg, sender, hostname);
  if (extraReady) run();
  else if (typeof self.nodepLoadExtra === "function") {
    self.nodepLoadExtra().then(() => { extraReady = true; run(); }).catch(run);
  } else run();
});

async function handleMessage(msg, sender, hostname) {
  if (msg.type === "block-site") {
    const { custom = [], trusted = [] } = await chrome.storage.local.get(["custom", "trusted"]);
    const host = hostname.replace(/^www\./, "");
    if (!custom.includes(host)) custom.push(host);
    await chrome.storage.local.set({
      custom,
      trusted: trusted.filter((h) => h !== host)
    });
    cache = null;
    await syncDnrRules().catch(() => {});
    openBlockedPage(sender.tab.id, host, "user", 0, sender.tab.url);
  }
}
