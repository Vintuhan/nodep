// Настройка жалоб.
// NODEP_REPORT_API  — адрес твоего сервера проверки (Google Apps Script, см. ИНСТРУКЦИЯ-СЕРВЕР.txt).
//                     С ним жалобу проверяет ИИ, а честные сайты разблокируются за несколько секунд.
// NODEP_REPORT_FORM — запасной вариант: ссылка Google Form (см. ИНСТРУКЦИЯ-ЖАЛОБЫ.txt).
//                     Используется, только если NODEP_REPORT_API пуст.
self.NODEP_REPORT_API = "https://script.google.com/macros/s/AKfycbzBlD1k-6Lw1e2J56_CCPCf55PqoFZ9ry5LK4AzmTWNqnk_Ms72OATwW4gSBd4JqRfc2Q/exec";
self.NODEP_REPORT_FORM = "";
