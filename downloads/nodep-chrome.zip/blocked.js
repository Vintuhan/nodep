// Цитаты про лудоманию. Показывается случайная.
const QUOTES = [
  "Выигрывает не игрок, а тот, кто построил казино.",
  "Каждая ставка — это деньги, которые ты уже не вернёшь себе.",
  "Азарт обещает всё и забирает то, что у тебя было.",
  "Ты не отыгрываешься. Ты просто проигрываешь дольше.",
  "Самая выгодная ставка — закрыть эту вкладку."
];
document.getElementById("quote").textContent = QUOTES[Math.floor(Math.random() * QUOTES.length)];

const params = new URLSearchParams(location.search);
const host = (params.get("host") || "").replace(/^www\./, "");
const why = params.get("why") || "list";
const score = params.get("score") || "0";
const originalUrl = params.get("u") || "";

const DAY = 24 * 60 * 60 * 1000;
const REPORT_COOLDOWN_MS = 12 * 60 * 60 * 1000;
const REPORTS_PER_DAY = 15;
const REPORT_WAIT_SEC = 10;
const CONFIRM_WAIT_SEC = 5;

const toast = document.getElementById("toast");
let toastTimer;
function showToast(text) {
  toast.textContent = text;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 1800);
}
document.getElementById("support").addEventListener("click", (e) => {
  e.preventDefault();
  showToast("скоро будет доступно");
});

const panel = document.getElementById("panel");
const confirmPanel = document.getElementById("confirm");
const reportBtn = document.getElementById("report");
const closeTabBtn = document.getElementById("close-tab");
const reportNote = document.getElementById("report-note");
const confirmYes = document.getElementById("confirm-yes");
const confirmNo = document.getElementById("confirm-no");

let reportTimer = null;
let confirmTimer = null;
let reportReady = false;

function closeThisTab() {
  try {
    chrome.tabs.getCurrent((tab) => {
      if (tab && tab.id != null) {
        chrome.tabs.remove(tab.id, () => {
          if (chrome.runtime.lastError) window.close();
        });
      } else {
        window.close();
      }
    });
  } catch (e) {
    window.close();
  }
}

if (closeTabBtn) closeTabBtn.addEventListener("click", closeThisTab);
const closeMainTab = document.getElementById("close-main-tab");
if (closeMainTab) closeMainTab.addEventListener("click", closeThisTab);

/** Таймер на кнопке + полоска «загрузки» */
function armButton(btn, seconds, onReady) {
  const label = btn.querySelector(".btn-label");
  const bar = btn.querySelector(".btn-bar");
  const baseText = (label && label.dataset.base) || (label ? label.textContent : btn.textContent);
  if (label && !label.dataset.base) label.dataset.base = baseText.replace(/\s*\(\d+\)\s*$/, "");

  btn.disabled = true;
  btn.classList.add("loading");
  if (bar) {
    bar.style.transition = "none";
    bar.style.transform = "scaleX(0)";
    void bar.offsetWidth;
    bar.style.transition = "transform " + seconds + "s linear";
    bar.style.transform = "scaleX(1)";
  }

  let left = seconds;
  const tick = () => {
    if (label) label.textContent = label.dataset.base + " (" + left + ")";
  };
  tick();

  clearInterval(btn._nodepTimer);
  btn._nodepTimer = setInterval(() => {
    left--;
    if (left > 0) {
      tick();
      return;
    }
    clearInterval(btn._nodepTimer);
    btn._nodepTimer = null;
    btn.disabled = false;
    btn.classList.remove("loading");
    if (label) label.textContent = label.dataset.base;
    if (bar) {
      bar.style.transition = "none";
      bar.style.transform = "scaleX(0)";
    }
    if (onReady) onReady();
  }, 1000);
}

function resetButton(btn) {
  clearInterval(btn._nodepTimer);
  btn._nodepTimer = null;
  btn.disabled = true;
  btn.classList.remove("loading");
  const label = btn.querySelector(".btn-label");
  const bar = btn.querySelector(".btn-bar");
  if (label && label.dataset.base) label.textContent = label.dataset.base;
  if (bar) {
    bar.style.transition = "none";
    bar.style.transform = "scaleX(0)";
  }
}

document.getElementById("mistake").addEventListener("click", openPanel);
document.getElementById("close").addEventListener("click", closePanel);

async function openPanel() {
  document.getElementById("panel-host").textContent = host;
  panel.hidden = false;
  confirmPanel.hidden = true;
  closeTabBtn.hidden = true;
  reportBtn.hidden = false;
  await refreshReportState();
}

function closePanel() {
  panel.hidden = true;
  confirmPanel.hidden = true;
  clearInterval(reportBtn._nodepTimer);
  clearInterval(confirmYes._nodepTimer);
}

function hoursLeft(untilTs) {
  const ms = Math.max(0, untilTs - Date.now());
  const h = Math.ceil(ms / (60 * 60 * 1000));
  return h < 1 ? "меньше часа" : (h + " ч");
}

async function refreshReportState() {
  reportReady = false;
  const { reported = {}, reportLog = [] } = await chrome.storage.local.get(["reported", "reportLog"]);
  const last = reported[host] || 0;
  if (last && Date.now() - last < REPORT_COOLDOWN_MS) {
    resetButton(reportBtn);
    reportBtn.disabled = true;
    reportNote.textContent = "жалоба на этот сайт уже отправлена. следующая через " + hoursLeft(last + REPORT_COOLDOWN_MS);
    return;
  }
  const recent = reportLog.filter((t) => t > Date.now() - DAY);
  if (recent.length >= REPORTS_PER_DAY) {
    resetButton(reportBtn);
    reportBtn.disabled = true;
    reportNote.textContent = "дневной лимит жалоб исчерпан. попробуй завтра";
    return;
  }
  reportNote.textContent = "число жалоб ограничено. отправляй только если сайт точно не связан с азартными играми";
  armButton(reportBtn, REPORT_WAIT_SEC, () => { reportReady = true; });
}

// Клик по жалобе → окно подтверждения
reportBtn.addEventListener("click", () => {
  if (reportBtn.disabled || !reportReady) return;
  document.getElementById("confirm-host").textContent = host;
  panel.hidden = true;
  confirmPanel.hidden = false;
  armButton(confirmYes, CONFIRM_WAIT_SEC);
});

confirmNo.addEventListener("click", () => {
  confirmPanel.hidden = true;
  panel.hidden = false;
  // снова 10 сек на основную кнопку
  reportReady = false;
  armButton(reportBtn, REPORT_WAIT_SEC, () => { reportReady = true; });
});

confirmYes.addEventListener("click", () => {
  if (confirmYes.disabled) return;
  confirmPanel.hidden = true;
  panel.hidden = false;
  reportBtn.disabled = true;
  if (self.NODEP_REPORT_API) reportToServer(self.NODEP_REPORT_API);
  else reportToForm();
});

async function markReported() {
  const { reported = {}, reportLog = [] } = await chrome.storage.local.get(["reported", "reportLog"]);
  reported[host] = Date.now();
  const recent = reportLog.filter((t) => t > Date.now() - DAY);
  recent.push(Date.now());
  await chrome.storage.local.set({ reported, reportLog: recent });
}

async function reportToServer(api) {
  reportNote.textContent = "проверяем сайт… это может занять до 30 секунд";
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 45000);
  try {
    const response = await fetch(api, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify({
        host,
        why,
        score: Number(score) || 0,
        version: chrome.runtime.getManifest().version
      }),
      signal: controller.signal
    });
    clearTimeout(timeout);

    let result;
    try {
      result = await response.json();
    } catch (e) {
      throw new Error("bad json");
    }
    if (!result || result.ok === false) throw new Error("bad answer");

    await markReported();
    const text = result.message || result.note || "";

    if (result.status === "approved") {
      reportNote.textContent = text || "сайт обычный — разблокирован. можно закрыть вкладку";
      reportBtn.hidden = true;
      if (closeTabBtn) {
        closeTabBtn.hidden = false;
        closeTabBtn.textContent = "закрыть вкладку";
      }
      const { remoteWhitelist = [] } = await chrome.storage.local.get("remoteWhitelist");
      if (!remoteWhitelist.includes(host)) remoteWhitelist.push(host);
      await chrome.storage.local.set({ remoteWhitelist });
      return;
    }

    if (result.status === "rejected") {
      reportNote.textContent = text || "сайт связан с азартными играми, блокировка остаётся";
      return;
    }

    reportNote.textContent = text || "жалоба записана, проверим вручную";
  } catch (e) {
    clearTimeout(timeout);
    try {
      const { reported = {} } = await chrome.storage.local.get("reported");
      reported[host] = Date.now() - REPORT_COOLDOWN_MS + 10 * 60 * 1000;
      await chrome.storage.local.set({ reported });
    } catch (err) {}
    reportBtn.disabled = false;
    reportReady = true;
    reportNote.textContent = "сервер не ответил — жалоба НЕ записана. проверь интернет и нажми ещё раз";
  }
}

function parseForm(link) {
  try {
    const u = new URL(link);
    const fields = {};
    for (const [k, v] of u.searchParams) if (k.startsWith("entry.")) fields[v.trim().toUpperCase()] = k;
    const url = u.origin + u.pathname.replace(/\/viewform\/?$/, "/formResponse");
    return { url, fields };
  } catch (e) {
    return null;
  }
}

async function reportToForm() {
  const form = self.NODEP_REPORT_FORM ? parseForm(self.NODEP_REPORT_FORM) : null;
  if (!form || !form.fields.SITE) {
    reportNote.textContent = "жалобы пока не настроены";
    return;
  }

  const data = new URLSearchParams();
  const put = (name, value) => { if (form.fields[name]) data.append(form.fields[name], value); };
  put("SITE", host);
  put("WHY", why);
  put("SCORE", score);
  put("VERSION", chrome.runtime.getManifest().version);

  reportBtn.disabled = true;
  try {
    await fetch(form.url, {
      method: "POST",
      mode: "no-cors",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: data
    });
    await markReported();
    reportNote.textContent = "спасибо, жалоба отправлена на ручную проверку";
  } catch (e) {
    reportBtn.disabled = false;
    reportReady = true;
    reportNote.textContent = "не удалось отправить, проверь интернет";
  }
}
