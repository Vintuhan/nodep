// nodep project — подсчёт баллов. Чистые функции без обращения к странице.
(function () {
  const K = self.NODEP_KEYWORDS;
  let textMap = null;
  let structMap = null;

  function maps() {
    if (!textMap) {
      textMap = new Map(Object.entries(K.text));
      structMap = new Map(Object.entries(K.struct));
    }
  }

  function normalize(s) {
    return String(s || "")
      .toLowerCase()
      .replace(/ё/g, "е")
      .replace(/[^\p{L}\p{N}]+/gu, " ")
      .trim();
  }

  // Ищет в тексте слова и фразы из базы. В каждом месте берёт самую длинную фразу,
  // каждую находку считает один раз.
  function scoreTexts(pieces, map, seen) {
    let score = 0;
    const maxN = K.maxWords;
    for (const piece of pieces) {
      const words = normalize(piece).split(" ");
      if (words.length === 1 && words[0] === "") continue;
      let i = 0;
      while (i < words.length) {
        let hit = false;
        for (let n = Math.min(maxN, words.length - i); n >= 1; n--) {
          const phrase = n === 1 ? words[i] : words.slice(i, i + n).join(" ");
          const v = map.get(phrase);
          if (v !== undefined) {
            if (!seen.has(phrase)) { seen.add(phrase); score += v; }
            i += n;
            hit = true;
            break;
          }
        }
        if (!hit) i++;
      }
    }
    return score;
  }

  // название вкладки и заголовки
  function scoreTitleAndHeadings(pieces) {
    maps();
    return scoreTexts(pieces, textMap, new Set());
  }

  // видимый текст страницы (только начало) — вторая линия проверки, для сайтов с «пустыми» заголовками
  function scoreBody(text) {
    maps();
    const v = scoreTexts([String(text || "").slice(0, 4000)], textMap, new Set());
    return Math.max(-3, Math.min(6, v));
  }

  // кнопки и поля ввода
  function scoreStructure(pieces) {
    maps();
    return Math.min(8, Math.max(0, scoreTexts(pieces, structMap, new Set())));
  }

  // адрес сайта (hostname)
  function scoreDomain(host) {
    const h = String(host || "").toLowerCase().replace(/^www\./, "");
    const flat = h.replace(/[.\-_]/g, "");
    let s = 0;
    for (const item of K.domain) {
      const frag = item[0], w = item[1], except = item[2];
      if (!flat.includes(frag)) continue;
      if (except && except.some((e) => flat.includes(e))) continue;
      s += w;
    }
    for (const [tld, w] of K.tld) if (h.endsWith(tld)) s += w;
    return Math.min(s, 14);
  }


  // путь и весь URL: /case-battle/, subdomains и т.п.
  function scoreUrl(urlOrPath) {
    const raw = String(urlOrPath || "").toLowerCase();
    let host = "";
    let blob = raw;
    try {
      if (/^https?:/.test(raw)) {
        const u = new URL(raw);
        host = u.hostname.replace(/^www\./, "");
        // поиск в Google/Yandex и т.п. — не блокируем по query
        if (/(^|\.)(google|google\.[a-z.]+|yandex|ya\.ru|bing|duckduckgo|yahoo|baidu|mail\.ru)$/.test(host)
            || /^(www\.)?(google|yandex|bing|duckduckgo)\./.test(host)) {
          return 0;
        }
        blob = u.hostname + u.pathname + u.search;
      }
    } catch (e) {}
    const compact = blob.replace(/[^a-z0-9]/g, "");
    let s = 0;
    for (const item of K.domain) {
      const frag = item[0], w = item[1], except = item[2];
      if (w < 6) continue;
      if (!compact.includes(frag)) continue;
      if (except && except.some((e) => compact.includes(e))) continue;
      s += w;
    }
    return Math.min(s, 14);
  }


  // Итоговое решение: 'block' (блокируем сразу), 'ask' (спрашиваем) или 'none'.
  const T = {
    ASK: 3,        // от скольки баллов показываем плашку
    BLOCK: 7,      // от скольки баллов блокируем, если на странице есть кнопки игры/депозита
    STRUCT_MIN: 2, // сколько баллов должны дать кнопки и формы для такой блокировки
    HARD: 12,      // от скольки баллов блокируем и без кнопок
    CERTAIN: 12    // известный бренд в адресе сайта — блокируем сразу
  };

  // article = страница похожа на статью/новость/лонгрид. У статей нет кнопок «играть» и «депозит»,
  // поэтому статья про казино никогда не блокируется сама, максимум спросит.
  function decide(domainS, textS, bodyS, structS, article) {
    let total = domainS + textS + bodyS + structS;
    if (domainS >= T.CERTAIN) return "block";
    if (article && structS < T.STRUCT_MIN) {
      total -= 10;
      return total >= 10 ? "ask" : "none";
    }
    if (total >= T.HARD) return "block";
    if (total >= T.BLOCK && structS >= T.STRUCT_MIN) return "block";
    // домен уже пахнет игоркой + любой намёк на странице → блок без ожидания SPA
    if (domainS >= 6 && total >= 8) return "block";
    if (total >= T.ASK) return "ask";
    return "none";
  }

  self.NodepScoring = Object.assign({
    normalize, scoreTitleAndHeadings, scoreBody, scoreStructure, scoreDomain, scoreUrl, decide
  }, T);
})();
