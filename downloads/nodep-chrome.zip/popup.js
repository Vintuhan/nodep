const button = document.getElementById("block");
const status = document.getElementById("status");
const modal = document.getElementById("modal");
const modalText = document.getElementById("modal-text");
const modalSub = document.getElementById("modal-sub");
const yes = document.getElementById("yes");
const no = document.getElementById("no");

let currentTab = null;
let currentHost = null;
let onYes = null;

async function init() {
  await self.nodepLoadExtra();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTab = tab;
  try {
    const url = new URL(tab.url);
    if (url.protocol !== "http:" && url.protocol !== "https:") throw new Error("not web");
    currentHost = url.hostname.replace(/^www\./, "");
    status.textContent = currentHost;
  } catch (e) {
    button.disabled = true;
    status.textContent = "эту страницу заблокировать нельзя";
  }
}

function openModal({ text, sub, confirm }) {
  modalText.textContent = text;
  modalSub.textContent = sub || "";
  document.getElementById("modal-row").style.display = "flex";
  if (confirm) {
    yes.textContent = "да";
    no.textContent = "нет";
    no.hidden = false;
    onYes = confirm;
  } else {
    yes.textContent = "понятно";
    no.hidden = true;
    onYes = null;
  }
  modal.hidden = false;
  yes.focus();
}
function closeModal() { modal.hidden = true; }

button.addEventListener("click", () => {
  if (!currentHost) return;
  if (self.nodepIsWhitelisted(currentHost)) {
    openModal({ text: "данный сайт в белом списке", sub: "блокировать его не нужно" });
  } else {
    openModal({
      text: "заблокировать этот сайт?",
      sub: currentHost,
      confirm: blockCurrent
    });
  }
});

yes.addEventListener("click", () => {
  const action = onYes;
  closeModal();
  if (action) action();
});
no.addEventListener("click", closeModal);

async function blockCurrent() {
  const { custom = [], trusted = [] } = await chrome.storage.local.get(["custom", "trusted"]);
  if (!custom.includes(currentHost)) custom.push(currentHost);
  await chrome.storage.local.set({ custom, trusted: trusted.filter((h) => h !== currentHost) });
  button.disabled = true;
  status.textContent = "сайт заблокирован";
  try { await chrome.runtime.sendMessage({ type: "force-update" }); } catch (e) {}
  const target = chrome.runtime.getURL("blocked.html") + "?host=" + encodeURIComponent(currentHost) + "&why=user";
  setTimeout(() => chrome.tabs.update(currentTab.id, { url: target }), 400);
}

init();
